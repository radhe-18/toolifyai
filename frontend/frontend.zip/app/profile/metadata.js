export const metadata = {
  title: "My Profile – ToolifyAI User Dashboard",
  description: "Manage your ToolifyAI account, saved tools, preferences, and personalized AI recommendations from your profile dashboard.",
  keywords: "ToolifyAI profile, user dashboard, saved tools, AI recommendations",
};
